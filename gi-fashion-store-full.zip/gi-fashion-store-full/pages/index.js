import Header from '../components/Header';

export default function Home() {
  return (
    <div>
      <Header />
      <main style={{padding: '1rem'}}>
        <h2>مرحبا بكم في متجر GI</h2>
        <p>اكتشف أحدث صيحات الموضة الرجالي والحريمي</p>
      </main>
    </div>
  );
}

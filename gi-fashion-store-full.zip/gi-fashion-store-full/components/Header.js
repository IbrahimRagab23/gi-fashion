export default function Header() {
  return (
    <header style={{padding: '1rem', background: '#000', color: '#fff'}}>
      <img src="/logo.png" alt="GI Logo" height="40" />
      <h1>GI Fashion Store</h1>
    </header>
  );
}
